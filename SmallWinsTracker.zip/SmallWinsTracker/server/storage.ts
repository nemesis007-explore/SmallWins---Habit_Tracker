import { 
  users, type User, type InsertUser,
  tasks, type Task, type InsertTask,
  categories, type Category, type InsertCategory,
  categoryOptions, type CategoryOption, type InsertCategoryOption,
  completedTasks, type CompletedTask, type InsertCompletedTask,
  selectedOptions, type SelectedOption, type InsertSelectedOption,
  dailyRecords, type DailyRecord, type InsertDailyRecord,
  type SummaryItem
} from "@shared/schema";
import { format, startOfDay, endOfDay, isEqual } from "date-fns";

// Storage interface
export interface IStorage {
  // User methods (keeping from original template)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Task methods
  getTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  deleteTask(id: number): Promise<void>;
  
  // Category methods
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryByName(name: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Category option methods
  getCategoryOptions(categoryId: number): Promise<CategoryOption[]>;
  getCategoryOption(id: number): Promise<CategoryOption | undefined>;
  createCategoryOption(option: InsertCategoryOption): Promise<CategoryOption>;
  
  // Completed task methods
  getCompletedTasksByDate(date: Date): Promise<CompletedTask[]>;
  createCompletedTask(task: InsertCompletedTask): Promise<CompletedTask>;
  deleteCompletedTask(taskId: number, date: Date): Promise<void>;
  
  // Selected option methods
  getSelectedOptionsByDate(date: Date): Promise<SelectedOption[]>;
  getSelectedOption(id: number): Promise<SelectedOption | undefined>;
  createSelectedOption(option: InsertSelectedOption): Promise<SelectedOption>;
  deleteSelectedOption(optionId: number, date: Date): Promise<void>;
  deleteSelectedOptionsByCategory(optionIds: number[], date: Date): Promise<void>;
  
  // Daily record methods
  getDailyRecords(limit: number): Promise<DailyRecord[]>;
  getDailyRecordsByDateRange(startDate: Date, endDate: Date): Promise<DailyRecord[]>;
  getDailyRecordByDate(date: Date): Promise<DailyRecord | undefined>;
  createDailyRecord(record: { date: Date; totalScore: number; dailyGoal: number; completedTasksCount: number; summary: SummaryItem[] }): Promise<DailyRecord>;
  updateDailyRecord(id: number, data: { totalScore: number; dailyGoal: number; completedTasksCount: number; summary: SummaryItem[] }): Promise<DailyRecord>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private taskMap: Map<number, Task>;
  private categoryMap: Map<number, Category>;
  private categoryOptionMap: Map<number, CategoryOption>;
  private completedTaskMap: Map<number, CompletedTask>;
  private selectedOptionMap: Map<number, SelectedOption>;
  private dailyRecordMap: Map<number, DailyRecord>;
  
  currentUserId: number;
  currentTaskId: number;
  currentCategoryId: number;
  currentCategoryOptionId: number;
  currentCompletedTaskId: number;
  currentSelectedOptionId: number;
  currentDailyRecordId: number;

  constructor() {
    this.users = new Map();
    this.taskMap = new Map();
    this.categoryMap = new Map();
    this.categoryOptionMap = new Map();
    this.completedTaskMap = new Map();
    this.selectedOptionMap = new Map();
    this.dailyRecordMap = new Map();
    
    this.currentUserId = 1;
    this.currentTaskId = 1;
    this.currentCategoryId = 1;
    this.currentCategoryOptionId = 1;
    this.currentCompletedTaskId = 1;
    this.currentSelectedOptionId = 1;
    this.currentDailyRecordId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Task methods
  async getTasks(): Promise<Task[]> {
    return Array.from(this.taskMap.values());
  }
  
  async getTask(id: number): Promise<Task | undefined> {
    return this.taskMap.get(id);
  }
  
  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.currentTaskId++;
    const task: Task = { ...insertTask, id };
    this.taskMap.set(id, task);
    return task;
  }
  
  async deleteTask(id: number): Promise<void> {
    this.taskMap.delete(id);
  }
  
  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categoryMap.values());
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categoryMap.get(id);
  }
  
  async getCategoryByName(name: string): Promise<Category | undefined> {
    return Array.from(this.categoryMap.values()).find(
      (category) => category.name === name,
    );
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const category: Category = { ...insertCategory, id };
    this.categoryMap.set(id, category);
    return category;
  }
  
  // Category option methods
  async getCategoryOptions(categoryId: number): Promise<CategoryOption[]> {
    return Array.from(this.categoryOptionMap.values()).filter(
      (option) => option.categoryId === categoryId,
    );
  }
  
  async getCategoryOption(id: number): Promise<CategoryOption | undefined> {
    return this.categoryOptionMap.get(id);
  }
  
  async createCategoryOption(insertOption: InsertCategoryOption): Promise<CategoryOption> {
    const id = this.currentCategoryOptionId++;
    const option: CategoryOption = { ...insertOption, id };
    this.categoryOptionMap.set(id, option);
    return option;
  }
  
  // Completed task methods
  async getCompletedTasksByDate(date: Date): Promise<CompletedTask[]> {
    const startOfTheDay = startOfDay(date).getTime();
    const endOfTheDay = endOfDay(date).getTime();
    
    return Array.from(this.completedTaskMap.values()).filter((task) => {
      const taskDate = new Date(task.date).getTime();
      return taskDate >= startOfTheDay && taskDate <= endOfTheDay;
    });
  }
  
  async createCompletedTask(insertTask: InsertCompletedTask): Promise<CompletedTask> {
    const id = this.currentCompletedTaskId++;
    const task: CompletedTask = { ...insertTask, id };
    this.completedTaskMap.set(id, task);
    return task;
  }
  
  async deleteCompletedTask(taskId: number, date: Date): Promise<void> {
    const startOfTheDay = startOfDay(date).getTime();
    const endOfTheDay = endOfDay(date).getTime();
    
    // Find the completed task for this specific task ID on this date
    const completedTask = Array.from(this.completedTaskMap.values()).find((task) => {
      const taskDate = new Date(task.date).getTime();
      return task.taskId === taskId && taskDate >= startOfTheDay && taskDate <= endOfTheDay;
    });
    
    if (completedTask) {
      this.completedTaskMap.delete(completedTask.id);
    }
  }
  
  // Selected option methods
  async getSelectedOptionsByDate(date: Date): Promise<SelectedOption[]> {
    const startOfTheDay = startOfDay(date).getTime();
    const endOfTheDay = endOfDay(date).getTime();
    
    return Array.from(this.selectedOptionMap.values()).filter((option) => {
      const optionDate = new Date(option.date).getTime();
      return optionDate >= startOfTheDay && optionDate <= endOfTheDay;
    });
  }
  
  async getSelectedOption(id: number): Promise<SelectedOption | undefined> {
    return this.selectedOptionMap.get(id);
  }
  
  async createSelectedOption(insertOption: InsertSelectedOption): Promise<SelectedOption> {
    const id = this.currentSelectedOptionId++;
    const option: SelectedOption = { ...insertOption, id };
    this.selectedOptionMap.set(id, option);
    return option;
  }
  
  async deleteSelectedOption(optionId: number, date: Date): Promise<void> {
    const startOfTheDay = startOfDay(date).getTime();
    const endOfTheDay = endOfDay(date).getTime();
    
    // Find the selected option for this specific option ID on this date
    const selectedOption = Array.from(this.selectedOptionMap.values()).find((option) => {
      const optionDate = new Date(option.date).getTime();
      return option.optionId === optionId && optionDate >= startOfTheDay && optionDate <= endOfTheDay;
    });
    
    if (selectedOption) {
      this.selectedOptionMap.delete(selectedOption.id);
    }
  }
  
  async deleteSelectedOptionsByCategory(optionIds: number[], date: Date): Promise<void> {
    const startOfTheDay = startOfDay(date).getTime();
    const endOfTheDay = endOfDay(date).getTime();
    
    // Find and delete all selected options from this category on this date
    const selectedOptions = Array.from(this.selectedOptionMap.values()).filter((option) => {
      const optionDate = new Date(option.date).getTime();
      return optionIds.includes(option.optionId) && optionDate >= startOfTheDay && optionDate <= endOfTheDay;
    });
    
    for (const option of selectedOptions) {
      this.selectedOptionMap.delete(option.id);
    }
  }
  
  // Daily record methods
  async getDailyRecords(limit: number): Promise<DailyRecord[]> {
    // Sort by date in descending order and limit
    return Array.from(this.dailyRecordMap.values())
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, limit);
  }
  
  async getDailyRecordsByDateRange(startDate: Date, endDate: Date): Promise<DailyRecord[]> {
    const startTimestamp = startOfDay(startDate).getTime();
    const endTimestamp = endOfDay(endDate).getTime();
    
    return Array.from(this.dailyRecordMap.values())
      .filter((record) => {
        const recordDate = new Date(record.date).getTime();
        return recordDate >= startTimestamp && recordDate <= endTimestamp;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }
  
  async getDailyRecordByDate(date: Date): Promise<DailyRecord | undefined> {
    const targetDate = startOfDay(date);
    
    return Array.from(this.dailyRecordMap.values()).find((record) => {
      const recordDate = startOfDay(new Date(record.date));
      return isEqual(recordDate, targetDate);
    });
  }
  
  async createDailyRecord(data: { date: Date; totalScore: number; dailyGoal: number; completedTasksCount: number; summary: SummaryItem[] }): Promise<DailyRecord> {
    const id = this.currentDailyRecordId++;
    const record: DailyRecord = { 
      ...data,
      id,
    };
    this.dailyRecordMap.set(id, record);
    return record;
  }
  
  async updateDailyRecord(id: number, data: { totalScore: number; dailyGoal: number; completedTasksCount: number; summary: SummaryItem[] }): Promise<DailyRecord> {
    const record = this.dailyRecordMap.get(id);
    if (!record) {
      throw new Error(`Daily record with ID ${id} not found`);
    }
    
    const updatedRecord: DailyRecord = {
      ...record,
      ...data,
    };
    
    this.dailyRecordMap.set(id, updatedRecord);
    return updatedRecord;
  }
}

export const storage = new MemStorage();
