import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { format, startOfDay, subDays, parseISO } from "date-fns";
import { SummaryItem, insertTaskSchema, insertCategorySchema, insertCategoryOptionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes - prefix all routes with /api
  
  // Tasks
  app.get("/api/tasks", async (req, res) => {
    const tasks = await storage.getTasks();
    res.json(tasks);
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const data = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(data);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create task" });
      }
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteTask(id);
    res.status(204).end();
  });

  // Categories
  app.get("/api/categories", async (req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });

  app.post("/api/categories", async (req, res) => {
    try {
      const data = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(data);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create category" });
      }
    }
  });

  // Category options
  app.get("/api/categories/:id/options", async (req, res) => {
    const categoryId = parseInt(req.params.id);
    const options = await storage.getCategoryOptions(categoryId);
    res.json(options);
  });

  app.get("/api/categories/time-of-day/options", async (req, res) => {
    const timeCategory = await storage.getCategoryByName("Time of Day");
    if (!timeCategory) {
      return res.status(404).json({ message: "Time of Day category not found" });
    }
    const options = await storage.getCategoryOptions(timeCategory.id);
    res.json(options);
  });

  app.post("/api/category-options", async (req, res) => {
    try {
      const data = insertCategoryOptionSchema.parse(req.body);
      const option = await storage.createCategoryOption(data);
      res.status(201).json(option);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create category option" });
      }
    }
  });

  // Completed Tasks
  app.get("/api/completed-tasks/today", async (req, res) => {
    const today = startOfDay(new Date());
    const completedTasks = await storage.getCompletedTasksByDate(today);
    res.json(completedTasks);
  });

  app.post("/api/completed-tasks", async (req, res) => {
    try {
      const { taskId } = req.body;
      if (!taskId) {
        return res.status(400).json({ message: "Task ID is required" });
      }
      
      const date = new Date();
      const completedTask = await storage.createCompletedTask({ taskId, date });
      
      // Update daily score
      await updateDailyScore();
      
      res.status(201).json(completedTask);
    } catch (error) {
      res.status(500).json({ message: "Failed to mark task as completed" });
    }
  });

  app.delete("/api/completed-tasks/:taskId", async (req, res) => {
    try {
      const taskId = parseInt(req.params.taskId);
      const today = startOfDay(new Date());
      await storage.deleteCompletedTask(taskId, today);
      
      // Update daily score
      await updateDailyScore();
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to unmark task" });
    }
  });

  // Selected Options
  app.get("/api/selected-options/today", async (req, res) => {
    const today = startOfDay(new Date());
    const selectedOptions = await storage.getSelectedOptionsByDate(today);
    res.json(selectedOptions);
  });

  app.post("/api/selected-options", async (req, res) => {
    try {
      const { optionId } = req.body;
      if (!optionId) {
        return res.status(400).json({ message: "Option ID is required" });
      }
      
      const date = new Date();
      
      // First, check if there's already a selected option from the same category
      const option = await storage.getCategoryOption(optionId);
      if (!option) {
        return res.status(404).json({ message: "Option not found" });
      }
      
      const categoryOptions = await storage.getCategoryOptions(option.categoryId);
      const optionIds = categoryOptions.map(o => o.id);
      
      // Remove any existing selections from this category
      await storage.deleteSelectedOptionsByCategory(optionIds, date);
      
      // Add the new selection
      const selectedOption = await storage.createSelectedOption({ optionId, date });
      
      // Update daily score
      await updateDailyScore();
      
      res.status(201).json(selectedOption);
    } catch (error) {
      res.status(500).json({ message: "Failed to select option" });
    }
  });

  app.delete("/api/selected-options/:optionId", async (req, res) => {
    try {
      const optionId = parseInt(req.params.optionId);
      const today = startOfDay(new Date());
      await storage.deleteSelectedOption(optionId, today);
      
      // Update daily score
      await updateDailyScore();
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to deselect option" });
    }
  });

  // Daily Score
  app.get("/api/daily-score/today", async (req, res) => {
    const today = startOfDay(new Date());
    let dailyRecord = await storage.getDailyRecordByDate(today);
    
    if (!dailyRecord) {
      // Calculate the score and create a record if it doesn't exist
      dailyRecord = await updateDailyScore();
    }
    
    res.json(dailyRecord);
  });

  // Daily Records (for history)
  app.get("/api/daily-records", async (req, res) => {
    const records = await storage.getDailyRecords(10);
    res.json(records);
  });

  app.get("/api/daily-records/weekly", async (req, res) => {
    const today = new Date();
    const lastWeek = subDays(today, 6); // Last 7 days including today
    const weeklyRecords = await storage.getDailyRecordsByDateRange(lastWeek, today);
    res.json(weeklyRecords);
  });

  // Helper function to calculate and update the daily score
  async function updateDailyScore() {
    const today = startOfDay(new Date());
    const completedTasks = await storage.getCompletedTasksByDate(today);
    const selectedOptions = await storage.getSelectedOptionsByDate(today);
    
    // Calculate total score from completed tasks
    let totalScore = 0;
    const summary: SummaryItem[] = [];
    
    // Add scores from completed tasks
    for (const completed of completedTasks) {
      const task = await storage.getTask(completed.taskId);
      if (task) {
        totalScore += task.score;
        summary.push({
          name: task.name,
          score: task.score,
          type: 'task'
        });
      }
    }
    
    // Add scores from selected options
    for (const selected of selectedOptions) {
      const option = await storage.getCategoryOption(selected.optionId);
      if (option) {
        const category = await storage.getCategory(option.categoryId);
        totalScore += option.score;
        summary.push({
          name: option.name,
          score: option.score,
          type: category ? category.name.toLowerCase() : 'option'
        });
      }
    }
    
    // Daily goal default is 50 points
    const dailyGoal = 50;
    
    // Check if a record already exists for today
    const existingRecord = await storage.getDailyRecordByDate(today);
    
    if (existingRecord) {
      // Update existing record
      return await storage.updateDailyRecord(existingRecord.id, {
        totalScore,
        completedTasksCount: completedTasks.length,
        dailyGoal: existingRecord.dailyGoal || dailyGoal,
        summary
      });
    } else {
      // Create new record
      return await storage.createDailyRecord({
        date: today,
        totalScore,
        dailyGoal,
        completedTasksCount: completedTasks.length,
        summary
      });
    }
  }

  // Initialize the data if it's empty
  await initializeData();

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to set up initial data
async function initializeData() {
  // Check if we already have categories
  const existingCategories = await storage.getCategories();
  
  // Determine if this is a fresh setup
  const isFreshSetup = existingCategories.length === 0;
  
  // Create or find time category
  let timeCategory;
  
  if (isFreshSetup) {
    // Create default categories
    const tasksCategory = await storage.createCategory({
      name: "Tasks",
      type: "options",
      isSystem: true,
    });
    
    timeCategory = await storage.createCategory({
      name: "Time of Day",
      type: "options",
      isSystem: true,
    });
    
    const energyCategory = await storage.createCategory({
      name: "Energy Level",
      type: "scale",
      isSystem: true,
    });
    
    // Create some default tasks
    const defaultTasks = [
      { name: "Morning Meditation", score: 7, categoryId: tasksCategory.id },
      { name: "Read 30 minutes", score: 5, categoryId: tasksCategory.id },
      { name: "Drink 2L water", score: 3, categoryId: tasksCategory.id },
      { name: "Exercise for 20 minutes", score: 8, categoryId: tasksCategory.id },
      { name: "Write in journal", score: 4, categoryId: tasksCategory.id },
    ];
    
    for (const task of defaultTasks) {
      await storage.createTask(task);
    }
  } else {
    // Find existing time category
    timeCategory = existingCategories.find(c => c.name === "Time of Day");
  }
  
  // Always ensure time options exist
  if (timeCategory) {
    const existingTimeOptions = await storage.getCategoryOptions(timeCategory.id);
    
    if (existingTimeOptions.length === 0) {
      // Create time of day options
      const timeOptions = [
        { name: "Morning", score: 8 },
        { name: "Afternoon", score: 5 },
        { name: "Evening", score: 6 },
        { name: "Night", score: 3 },
      ];
      
      for (const option of timeOptions) {
        await storage.createCategoryOption({
          categoryId: timeCategory.id,
          name: option.name,
          score: option.score,
        });
      }
    }
  }
}
