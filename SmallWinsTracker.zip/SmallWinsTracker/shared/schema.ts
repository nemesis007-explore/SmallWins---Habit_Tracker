import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (keeping from the original template)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Tasks schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  score: integer("score").notNull(),
  categoryId: integer("category_id").notNull(),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  name: true,
  score: true,
  categoryId: true,
});

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

// Categories schema
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // "scale" or "options"
  isSystem: boolean("is_system").default(false), // to mark system categories
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  type: true,
  isSystem: true,
});

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

// Category options schema (for options-type categories)
export const categoryOptions = pgTable("category_options", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id").notNull(),
  name: text("name").notNull(),
  score: integer("score").notNull(),
});

export const insertCategoryOptionSchema = createInsertSchema(categoryOptions).pick({
  categoryId: true,
  name: true,
  score: true,
});

export type InsertCategoryOption = z.infer<typeof insertCategoryOptionSchema>;
export type CategoryOption = typeof categoryOptions.$inferSelect;

// Completed tasks for today
export const completedTasks = pgTable("completed_tasks", {
  id: serial("id").primaryKey(),
  taskId: integer("task_id").notNull(),
  date: timestamp("date").notNull().defaultNow(),
});

export const insertCompletedTaskSchema = createInsertSchema(completedTasks).pick({
  taskId: true,
  date: true,
});

export type InsertCompletedTask = z.infer<typeof insertCompletedTaskSchema>;
export type CompletedTask = typeof completedTasks.$inferSelect;

// Selected category options for today
export const selectedOptions = pgTable("selected_options", {
  id: serial("id").primaryKey(),
  optionId: integer("option_id").notNull(),
  date: timestamp("date").notNull().defaultNow(),
});

export const insertSelectedOptionSchema = createInsertSchema(selectedOptions).pick({
  optionId: true,
  date: true,
});

export type InsertSelectedOption = z.infer<typeof insertSelectedOptionSchema>;
export type SelectedOption = typeof selectedOptions.$inferSelect;

// Daily record schema
export const dailyRecords = pgTable("daily_records", {
  id: serial("id").primaryKey(),
  date: timestamp("date").notNull(),
  totalScore: integer("total_score").notNull(),
  dailyGoal: integer("daily_goal").notNull().default(50), // Default daily point goal
  completedTasksCount: integer("completed_tasks_count").notNull(),
  summary: json("summary").notNull(), // Store items that contributed to the score
});

export const insertDailyRecordSchema = createInsertSchema(dailyRecords).pick({
  date: true,
  totalScore: true,
  dailyGoal: true,
  completedTasksCount: true,
  summary: true,
});

export type InsertDailyRecord = z.infer<typeof insertDailyRecordSchema>;
export type DailyRecord = typeof dailyRecords.$inferSelect;

// Summary item type (for the json field in daily records)
export const summaryItemSchema = z.object({
  name: z.string(),
  score: z.number(),
  type: z.string(), // "task", "time", "energy", etc.
});

export type SummaryItem = z.infer<typeof summaryItemSchema>;

// Daily record with formatted summary
export type DailyRecordWithSummary = DailyRecord & {
  formattedSummary: SummaryItem[];
};
