import React, { createContext, useContext, useState, ReactNode } from 'react';

interface SmallWinsContextType {
  addTaskOpen: boolean;
  setAddTaskOpen: (open: boolean) => void;
  addCategoryOpen: boolean;
  setAddCategoryOpen: (open: boolean) => void;
}

const SmallWinsContext = createContext<SmallWinsContextType | undefined>(undefined);

interface SmallWinsProviderProps {
  children: ReactNode;
}

export function SmallWinsProvider({ children }: SmallWinsProviderProps) {
  const [addTaskOpen, setAddTaskOpen] = useState(false);
  const [addCategoryOpen, setAddCategoryOpen] = useState(false);
  
  const value = {
    addTaskOpen,
    setAddTaskOpen,
    addCategoryOpen,
    setAddCategoryOpen
  };
  
  return (
    <SmallWinsContext.Provider value={value}>
      {children}
    </SmallWinsContext.Provider>
  );
}

export function useSmallWins() {
  const context = useContext(SmallWinsContext);
  if (context === undefined) {
    throw new Error('useSmallWins must be used within a SmallWinsProvider');
  }
  return context;
}
