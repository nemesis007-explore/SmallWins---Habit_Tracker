import React from 'react';
import { Slider } from '@/components/ui/slider';

interface RangeWithMarkersProps {
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step: number;
  label?: string;
}

export function RangeWithMarkers({
  value,
  onChange,
  min,
  max,
  step,
  label
}: RangeWithMarkersProps) {
  const markers = Array.from({ length: (max - min) / step + 1 }, (_, i) => min + i * step);
  
  return (
    <div>
      <div className="flex justify-between mb-2">
        <span className="text-sm text-neutral-500">Low</span>
        <span className="text-sm text-neutral-500">High</span>
      </div>
      <div className="relative h-8">
        <Slider
          value={[value]}
          min={min}
          max={max}
          step={step}
          onValueChange={(values) => onChange(values[0])}
          className="w-full h-2 absolute top-3"
        />
        <div className="absolute top-0 w-full flex justify-between px-1">
          {markers.map((mark) => (
            <div key={mark} className="h-8 w-px bg-neutral-200 relative">
              <span className={`absolute -bottom-5 text-xs ${mark === value ? 'text-neutral-500 font-medium' : 'text-neutral-400'}`}>
                {mark}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
