import React from 'react';
import { cn } from '@/lib/utils';

interface ScoreBadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  score: number;
  isCompleted?: boolean;
}

export function ScoreBadge({ score, isCompleted = false, className, ...props }: ScoreBadgeProps) {
  return (
    <span 
      className={cn(
        'score-badge inline-flex items-center justify-center font-semibold px-2 py-0.5 rounded-full text-xs',
        isCompleted 
          ? 'bg-neutral-200 text-neutral-600' 
          : 'bg-primary text-white',
        className
      )}
      {...props}
    >
      +{score}
    </span>
  );
}
