import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  CalendarCheck, 
  ListTodo, 
  History, 
  User, 
  Settings, 
  Plus
} from "lucide-react";
import { AddTaskDialog } from "@/components/dialogs/AddTaskDialog";
import { AddCategoryDialog } from "@/components/dialogs/AddCategoryDialog";
import { useSmallWins } from "@/hooks/use-smallwins";

type AppLayoutProps = {
  children: ReactNode;
};

export default function AppLayout({ children }: AppLayoutProps) {
  const [location] = useLocation();
  const { addTaskOpen, setAddTaskOpen, addCategoryOpen, setAddCategoryOpen } = useSmallWins();

  return (
    <div className="max-w-4xl mx-auto pb-20 md:pb-8">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-sm">
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-primary">SmallWins</h1>
            <span className="ml-1 text-xs bg-primary text-white px-1 rounded">Beta</span>
          </div>
          <div className="flex items-center space-x-3">
            <button className="p-2 rounded-full hover:bg-neutral-100">
              <Settings className="h-5 w-5 text-neutral-600" />
            </button>
            <button className="p-2 rounded-full hover:bg-neutral-100">
              <User className="h-5 w-5 text-neutral-600" />
            </button>
          </div>
        </div>
        
        {/* Navigation Tabs */}
        <div className="px-4 pb-0 flex border-b">
          <Link href="/">
            <a className={`py-3 px-4 border-b-2 ${location === "/" ? "border-primary text-primary font-medium" : "border-transparent hover:text-primary"}`}>
              Today
            </a>
          </Link>
          <Link href="/tasks">
            <a className={`py-3 px-4 border-b-2 ${location === "/tasks" ? "border-primary text-primary font-medium" : "border-transparent hover:text-primary"}`}>
              Tasks
            </a>
          </Link>
          <Link href="/history">
            <a className={`py-3 px-4 border-b-2 ${location === "/history" ? "border-primary text-primary font-medium" : "border-transparent hover:text-primary"}`}>
              History
            </a>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-4 py-6">
        {children}
      </main>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around">
        <Link href="/">
          <a className={`flex flex-col items-center py-2 px-4 ${location === "/" ? "text-primary" : "text-neutral-500"}`}>
            <CalendarCheck className="h-6 w-6" />
            <span className="text-xs mt-1">Today</span>
          </a>
        </Link>
        <Link href="/tasks">
          <a className={`flex flex-col items-center py-2 px-4 ${location === "/tasks" ? "text-primary" : "text-neutral-500"}`}>
            <ListTodo className="h-6 w-6" />
            <span className="text-xs mt-1">Tasks</span>
          </a>
        </Link>
        <button 
          className="flex flex-col items-center py-1 px-4"
          onClick={() => setAddTaskOpen(true)}
        >
          <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-white -mt-4">
            <Plus className="h-6 w-6" />
          </div>
          <span className="text-xs mt-1">Add</span>
        </button>
        <Link href="/history">
          <a className={`flex flex-col items-center py-2 px-4 ${location === "/history" ? "text-primary" : "text-neutral-500"}`}>
            <History className="h-6 w-6" />
            <span className="text-xs mt-1">History</span>
          </a>
        </Link>
        <button className="flex flex-col items-center py-2 px-4 text-neutral-500">
          <User className="h-6 w-6" />
          <span className="text-xs mt-1">Profile</span>
        </button>
      </div>

      {/* Dialogs */}
      <AddTaskDialog 
        open={addTaskOpen} 
        onOpenChange={setAddTaskOpen} 
      />
      
      <AddCategoryDialog 
        open={addCategoryOpen} 
        onOpenChange={setAddCategoryOpen}
      />
    </div>
  );
}
