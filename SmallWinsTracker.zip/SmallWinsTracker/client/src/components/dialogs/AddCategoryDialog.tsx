import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertCategorySchema } from '@shared/schema';
import { X, Plus, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

const formSchema = insertCategorySchema.extend({
  options: z.array(
    z.object({
      name: z.string().min(1, "Option name is required"),
      score: z.number().min(1).max(10)
    })
  ).optional(),
});

type CategoryFormValues = z.infer<typeof formSchema>;

type Option = {
  name: string;
  score: number;
};

type AddCategoryDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export function AddCategoryDialog({ open, onOpenChange }: AddCategoryDialogProps) {
  const { toast } = useToast();
  const [options, setOptions] = useState<Option[]>([
    { name: '', score: 5 },
    { name: '', score: 5 }
  ]);
  
  // Category form
  const form = useForm<CategoryFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      type: 'scale',
      isSystem: false,
    },
  });
  
  const categoryType = form.watch('type');
  
  const handleAddOption = () => {
    setOptions([...options, { name: '', score: 5 }]);
  };
  
  const handleRemoveOption = (index: number) => {
    setOptions(options.filter((_, i) => i !== index));
  };
  
  const handleOptionChange = (index: number, field: keyof Option, value: string | number) => {
    const newOptions = [...options];
    newOptions[index][field] = value as never;
    setOptions(newOptions);
  };
  
  // Add category mutation
  const addCategoryMutation = useMutation({
    mutationFn: async (data: CategoryFormValues) => {
      // First create the category
      const categoryRes = await apiRequest('POST', '/api/categories', {
        name: data.name,
        type: data.type,
        isSystem: false
      });
      
      const category = await categoryRes.json();
      
      // If category type is "options", create the options
      if (data.type === 'options' && options.length > 0) {
        const optionPromises = options.map(option => 
          apiRequest('POST', '/api/category-options', {
            categoryId: category.id,
            name: option.name,
            score: option.score
          })
        );
        
        await Promise.all(optionPromises);
      }
      
      return category;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      toast({
        title: 'Category created',
        description: 'Your new category has been added.',
      });
      form.reset();
      setOptions([{ name: '', score: 5 }, { name: '', score: 5 }]);
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to create category',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const onSubmit = (values: CategoryFormValues) => {
    // If type is options, validate that options are filled
    if (values.type === 'options') {
      const isValid = options.every(opt => opt.name.trim() !== '');
      if (!isValid) {
        toast({
          title: 'Invalid options',
          description: 'All option names must be filled out.',
          variant: 'destructive',
        });
        return;
      }
      values.options = options;
    }
    
    addCategoryMutation.mutate(values);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-white rounded-xl p-6 w-full max-w-md mx-4">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle className="text-lg font-semibold">Add New Category</DialogTitle>
            <Button 
              size="icon" 
              variant="ghost" 
              className="text-neutral-500 hover:text-neutral-700"
              onClick={() => onOpenChange(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium">Category Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter category name" 
                      className="w-full px-3 py-2 border rounded-lg" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium">Category Type</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="space-y-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="scale" id="scale" />
                        <label htmlFor="scale">Score Scale (1-10)</label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="options" id="options" />
                        <label htmlFor="options">Multiple Options</label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {categoryType === 'options' && (
              <div className="mb-4">
                <FormLabel className="text-sm font-medium">Options</FormLabel>
                <div className="space-y-2 mt-1">
                  {options.map((option, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Input
                        type="text"
                        className="flex-1 px-3 py-2 border rounded-lg text-sm"
                        placeholder="Option name"
                        value={option.name}
                        onChange={(e) => handleOptionChange(index, 'name', e.target.value)}
                      />
                      <Input
                        type="number"
                        min={1}
                        max={10}
                        className="w-16 px-3 py-2 border rounded-lg text-sm"
                        placeholder="Score"
                        value={option.score}
                        onChange={(e) => handleOptionChange(index, 'score', parseInt(e.target.value) || 5)}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="p-2 text-neutral-500 hover:text-neutral-700"
                        onClick={() => handleRemoveOption(index)}
                        disabled={options.length <= 2}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button 
                    type="button"
                    variant="ghost"
                    className="flex items-center text-sm text-primary p-0 hover:bg-transparent"
                    onClick={handleAddOption}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add Option
                  </Button>
                </div>
              </div>
            )}
            
            <DialogFooter className="flex space-x-3 mt-6">
              <Button
                type="button"
                variant="outline"
                className="flex-1 py-2 border rounded-lg text-neutral-700"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="flex-1 py-2 bg-primary text-white rounded-lg"
                disabled={addCategoryMutation.isPending}
              >
                {addCategoryMutation.isPending ? 'Adding...' : 'Add Category'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
