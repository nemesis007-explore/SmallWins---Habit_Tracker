import React from 'react';
import { Pencil } from 'lucide-react';
import { Category } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  // Get options if category has them
  const { data: options, isLoading } = useQuery({
    queryKey: ['/api/categories', category.id, 'options'],
    enabled: category.type === 'options'
  });

  let description = '';
  
  if (category.type === 'scale') {
    description = 'Scale from 1-10';
  } else if (category.type === 'options' && options) {
    // Format first few options
    const optionNames = options.map((o: any) => o.name);
    description = optionNames.slice(0, 3).join(', ');
    if (optionNames.length > 3) {
      description += `, +${optionNames.length - 3} more`;
    }
  }

  return (
    <div className="border rounded-lg p-4">
      <div className="flex justify-between items-center">
        <h4 className="font-medium">{category.name}</h4>
        <div className="text-neutral-500">
          <button className="p-1 hover:text-neutral-700">
            <Pencil className="h-4 w-4" />
          </button>
        </div>
      </div>
      <p className="text-sm text-neutral-500 mt-1">
        {isLoading ? 'Loading...' : description}
      </p>
    </div>
  );
}
