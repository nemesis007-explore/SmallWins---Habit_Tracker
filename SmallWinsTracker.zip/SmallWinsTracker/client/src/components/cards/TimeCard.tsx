import React from 'react';
import { useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { CategoryOption } from '@shared/schema';
import { ScoreBadge } from '@/components/ui/score-badge';
import { Button } from '@/components/ui/button';

interface TimeCardProps {
  option: CategoryOption;
  isActive: boolean;
}

export function TimeCard({ option, isActive }: TimeCardProps) {
  const { toast } = useToast();

  // Toggle time option
  const toggleTimeMutation = useMutation({
    mutationFn: () => {
      const endpoint = isActive 
        ? `/api/selected-options/${option.id}` 
        : '/api/selected-options';
      
      const method = isActive ? 'DELETE' : 'POST';
      const data = isActive ? undefined : { optionId: option.id };
      
      return apiRequest(method, endpoint, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/selected-options/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/daily-score/today'] });
      
      toast({
        title: isActive ? 'Time deactivated' : 'Time activated',
        description: isActive 
          ? `${option.name} is no longer active` 
          : `${option.name} is now active. +${option.score} points!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleTimeToggle = () => {
    toggleTimeMutation.mutate();
  };

  return (
    <div className="time-card bg-white rounded-lg p-4 shadow-sm border border-neutral-100 flex flex-col items-center">
      <div className="text-center">
        <span className="text-sm font-medium block mb-1">{option.name}</span>
        <ScoreBadge 
          score={option.score} 
          isCompleted={!isActive} 
          className={isActive ? 'bg-accent text-white' : undefined}
        />
      </div>
      <Button
        variant={isActive ? "secondary" : "outline"}
        className={`mt-3 w-full py-1 rounded text-xs font-medium ${
          isActive 
            ? 'bg-accent/10 text-accent hover:bg-accent/20' 
            : 'bg-neutral-100 text-neutral-500 hover:bg-neutral-200'
        }`}
        onClick={handleTimeToggle}
        disabled={toggleTimeMutation.isPending}
      >
        {isActive ? 'Active Now' : 'Set Active'}
      </Button>
    </div>
  );
}
