import React from 'react';
import { useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { ScoreBadge } from '@/components/ui/score-badge';
import { Task } from '@shared/schema';
import { Pencil, Trash2 } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  isCompleted: boolean;
}

export function TaskCard({ task, isCompleted }: TaskCardProps) {
  const { toast } = useToast();

  // Toggle task completion
  const toggleTaskMutation = useMutation({
    mutationFn: () => {
      const endpoint = isCompleted 
        ? `/api/completed-tasks/${task.id}` 
        : '/api/completed-tasks';
      
      const method = isCompleted ? 'DELETE' : 'POST';
      const data = isCompleted ? undefined : { taskId: task.id };
      
      return apiRequest(method, endpoint, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/completed-tasks/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/daily-score/today'] });
      
      toast({
        title: isCompleted ? 'Task unmarked' : 'Task completed',
        description: isCompleted 
          ? `${task.name} has been unmarked` 
          : `${task.name} marked as completed. +${task.score} points!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleTaskToggle = () => {
    toggleTaskMutation.mutate();
  };

  return (
    <div className={`task-card bg-white rounded-lg p-4 shadow-sm border border-neutral-100 flex items-center justify-between ${isCompleted ? 'completed-task' : ''}`}>
      <div className="flex items-center">
        <div>
          <input 
            type="checkbox" 
            id={`task-${task.id}`} 
            className="task-checkbox sr-only"
            checked={isCompleted}
            onChange={handleTaskToggle}
            disabled={toggleTaskMutation.isPending}
          />
          <label htmlFor={`task-${task.id}`} className="flex items-center cursor-pointer">
            <span className={`w-5 h-5 inline-block mr-3 rounded border border-neutral-300 flex-shrink-0 ${isCompleted ? 'bg-secondary' : ''}`}></span>
            <span className={`font-medium ${isCompleted ? 'text-neutral-500 line-through' : ''}`}>
              {task.name}
            </span>
          </label>
        </div>
        <ScoreBadge score={task.score} isCompleted={isCompleted} className="ml-3" />
      </div>
      <div className="flex items-center text-neutral-400">
        <button className="p-1 hover:text-neutral-600">
          <Pencil className="h-4 w-4" />
        </button>
        <button className="p-1 hover:text-neutral-600 ml-1">
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
