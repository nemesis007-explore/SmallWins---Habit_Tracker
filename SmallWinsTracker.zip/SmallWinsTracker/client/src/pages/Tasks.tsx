import { useState } from "react";
import { Search, Plus, Pencil, Trash2 } from "lucide-react";
import { ScoreBadge } from "@/components/ui/score-badge";
import { CategoryCard } from "@/components/cards/CategoryCard";
import { useQuery } from "@tanstack/react-query";
import { useSmallWins } from "@/hooks/use-smallwins";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Task, Category } from "@shared/schema";

export default function Tasks() {
  const { setAddTaskOpen, setAddCategoryOpen } = useSmallWins();
  const [searchTerm, setSearchTerm] = useState("");
  
  // Fetch data
  const { data: tasks, isLoading: tasksLoading } = useQuery({
    queryKey: ['/api/tasks'],
  });

  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ['/api/categories'],
  });

  // Check if any data is still loading
  const isLoading = tasksLoading || categoriesLoading;

  if (isLoading) {
    return <div className="flex justify-center py-8">Loading...</div>;
  }

  // Filter tasks if search term exists
  const filteredTasks = searchTerm
    ? tasks?.filter((task: Task) => 
        task.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : tasks;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Manage Tasks</h2>
        <Button 
          className="bg-primary text-white px-4 py-2 rounded-lg flex items-center"
          onClick={() => setAddTaskOpen(true)}
        >
          <Plus className="h-4 w-4 mr-1" />
          New Task
        </Button>
      </div>
      
      <div className="bg-white rounded-xl p-5 shadow mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold">My Tasks</h3>
          <div className="relative">
            <Input
              type="text"
              placeholder="Search tasks..."
              className="pl-8 pr-3 py-1 text-sm w-48"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-2 top-2 h-4 w-4 text-neutral-400" />
          </div>
        </div>
        
        <div className="space-y-3">
          {filteredTasks?.length > 0 ? (
            filteredTasks.map((task: Task) => (
              <div key={task.id} className="flex items-center justify-between border-b pb-3">
                <div className="flex items-center">
                  <span className="font-medium">{task.name}</span>
                  <ScoreBadge score={task.score} className="ml-3" />
                </div>
                <div className="flex items-center space-x-2">
                  <button className="p-1.5 text-neutral-500 hover:text-neutral-700">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button className="p-1.5 text-neutral-500 hover:text-neutral-700">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-4 text-neutral-500">
              {searchTerm ? "No tasks match your search" : "No tasks yet. Add your first task!"}
            </div>
          )}
        </div>
      </div>
      
      <div className="bg-white rounded-xl p-5 shadow">
        <h3 className="font-semibold mb-4">Categories</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {categories?.map((category: Category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
          
          <div 
            className="border border-dashed rounded-lg p-4 flex items-center justify-center cursor-pointer hover:border-primary hover:text-primary"
            onClick={() => setAddCategoryOpen(true)}
          >
            <Plus className="h-4 w-4 mr-1" />
            <span>Add New Category</span>
          </div>
        </div>
      </div>
    </div>
  );
}
