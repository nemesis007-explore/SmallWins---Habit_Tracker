import { useState } from "react";
import { format } from "date-fns";
import { ScoreBadge } from "@/components/ui/score-badge";
import { TaskCard } from "@/components/cards/TaskCard";
import { TimeCard } from "@/components/cards/TimeCard";
import { RangeWithMarkers } from "@/components/ui/range-with-markers";
import { Pencil, Plus, TrophyIcon, ArrowUp } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useSmallWins } from "@/hooks/use-smallwins";
import { Task, CategoryOption, Category, DailyRecord } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function Today() {
  const { setAddTaskOpen, setAddCategoryOpen } = useSmallWins();
  const [energyLevel, setEnergyLevel] = useState(7);
  const [customDailyGoal, setCustomDailyGoal] = useState<number>(50);
  
  // Fetch data
  const { data: tasks, isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });

  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const { data: timeOptions, isLoading: timeOptionsLoading } = useQuery<CategoryOption[]>({
    queryKey: ['/api/categories/time-of-day/options'],
    refetchOnMount: true,
    refetchInterval: 5000, // Refetch periodically to make sure we pick up newly created options
  });

  const { data: completedTasks, isLoading: completedTasksLoading } = useQuery({
    queryKey: ['/api/completed-tasks/today'],
  });

  const { data: selectedOptions, isLoading: selectedOptionsLoading } = useQuery({
    queryKey: ['/api/selected-options/today'],
  });

  const { data: dailyScore, isLoading: dailyScoreLoading } = useQuery<DailyRecord>({
    queryKey: ['/api/daily-score/today'],
  });
  
  // Energy level mutation
  const energyMutation = useMutation({
    mutationFn: (level: number) => {
      // This would be implemented in a real app to save energy level
      return Promise.resolve(level);
    }
  });

  // Check if any data is still loading
  const isLoading = tasksLoading || categoriesLoading || timeOptionsLoading || 
                   completedTasksLoading || selectedOptionsLoading || dailyScoreLoading;

  if (isLoading) {
    return <div className="flex justify-center py-8">Loading...</div>;
  }

  // Find active time of day
  const activeTimeOption = timeOptions && timeOptions.find(option => 
    selectedOptions && selectedOptions.some(selected => selected.optionId === option.id)
  );

  // Calculate stats
  const completedTasksCount = completedTasks?.length || 0;
  const totalScore = dailyScore?.totalScore || 0;
  const dailyGoal = dailyScore?.dailyGoal || 50;
  const streakCount = 3; // This would come from API in a real implementation

  return (
    <div className="space-y-6">
      {/* Daily Goal Summary Block */}
      <div className="sticky top-[86px] z-40 bg-white border-b pb-2 -mx-4 px-4 mb-2">
        <div className="flex items-center justify-between mb-1 pt-2">
          <div className="flex items-center gap-2">
            <TrophyIcon className="h-5 w-5 text-accent" />
            <span className="font-medium">Daily Goal</span>
            <button 
              onClick={() => {
                const newGoal = window.prompt("Set your daily goal (10-100):", dailyGoal.toString());
                if (newGoal) {
                  const goalNumber = parseInt(newGoal);
                  if (!isNaN(goalNumber) && goalNumber >= 10 && goalNumber <= 100) {
                    setCustomDailyGoal(goalNumber);
                  }
                }
              }}
              className="ml-1 text-xs text-primary px-1.5 py-0.5 bg-primary/10 rounded-full hover:bg-primary/20"
            >
              Edit
            </button>
          </div>
          <div className="flex items-center">
            <div className="text-lg font-semibold text-primary">{totalScore}</div>
            <span className="text-neutral-400 mx-1">/</span>
            <div className="text-neutral-600">{customDailyGoal}</div>
            {totalScore > customDailyGoal && (
              <div className="ml-2 bg-accent/20 px-2 py-0.5 rounded-full text-xs text-accent font-medium flex items-center">
                <ArrowUp className="h-3 w-3 mr-0.5" />
                +{totalScore - customDailyGoal}
              </div>
            )}
          </div>
        </div>
        <div className="relative h-2 bg-neutral-100 rounded-full overflow-hidden">
          <div 
            className={`absolute left-0 top-0 h-full transition-all duration-500 ${
              totalScore >= customDailyGoal ? 'bg-gradient-to-r from-secondary to-accent' : 'bg-primary'
            }`}
            style={{ width: `${Math.min(100, (totalScore / customDailyGoal) * 100)}%` }}
          ></div>
        </div>
      </div>
        
      {/* Daily Goal Tracker */}
      <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-xl p-5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-xl font-bold">Today's Progress</h2>
            <p className="text-neutral-500">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
          </div>
          <div className="mt-4 md:mt-0 flex items-center">
            <div className="flex flex-col items-end">
              <div className="flex items-baseline">
                <span className="text-3xl font-bold text-primary">{totalScore}</span>
                <span className="text-neutral-600 ml-1">/ {dailyGoal}</span>
              </div>
              <div className="text-sm text-neutral-500">daily points</div>
            </div>
          </div>
        </div>
        
        <div className="mt-5">
          <div className="relative w-full h-6 bg-white/80 rounded-full overflow-hidden">
            <div 
              className={`absolute left-0 top-0 h-full transition-all duration-500 ${
                totalScore >= dailyGoal ? 'bg-gradient-to-r from-secondary to-accent' : 'bg-gradient-to-r from-primary to-secondary'
              }`}
              style={{ width: `${Math.min(100, (totalScore / dailyGoal) * 100)}%` }}
            ></div>
            
            {/* Goal marker */}
            <div className="absolute top-0 bottom-0 w-px bg-white border-r border-dashed border-neutral-400" 
              style={{ left: `${Math.min(100, (dailyGoal / (Math.max(totalScore, dailyGoal) * 1.2)) * 100)}%` }}>
              <div className="absolute top-0 -ml-2 px-1 bg-white text-xs font-medium rounded-b shadow-sm">
                Goal
              </div>
            </div>
            
            {/* Current score marker */}
            {totalScore > 0 && (
              <div className="absolute top-0 bottom-0 flex items-center justify-center"
                style={{ left: `${Math.min(98, (totalScore / (Math.max(totalScore, dailyGoal) * 1.2)) * 100)}%` }}>
                <div className="bg-white px-1 py-0.5 rounded text-xs font-bold shadow-sm">
                  {totalScore}
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="mt-5 flex flex-wrap gap-3">
          <div className="bg-white px-3 py-1 rounded-full text-sm text-primary shadow-sm">
            <span>{completedTasksCount}</span> tasks done
          </div>
          <div className="bg-white px-3 py-1 rounded-full text-sm text-secondary shadow-sm">
            <span>{streakCount}</span> day streak
          </div>
          {activeTimeOption && (
            <div className="bg-white px-3 py-1 rounded-full text-sm text-accent shadow-sm">
              <span>{activeTimeOption.name}</span> power hours
            </div>
          )}
        </div>
      </div>

      {/* Tasks Category */}
      <div className="category-section">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Tasks</h2>
          <button 
            className="text-sm text-primary font-medium"
            onClick={() => window.location.href = '/tasks'}
          >
            Manage
          </button>
        </div>
        
        <div className="space-y-3">
          {tasks?.map((task: Task) => (
            <TaskCard 
              key={task.id} 
              task={task} 
              isCompleted={completedTasks?.some(ct => ct.taskId === task.id) || false}
            />
          ))}
          
          <button 
            className="flex items-center justify-center w-full p-3 border border-dashed border-neutral-300 rounded-lg text-neutral-500 hover:text-primary hover:border-primary transition-colors"
            onClick={() => setAddTaskOpen(true)}
          >
            <Plus className="h-5 w-5 mr-1" />
            <span>Add New Task</span>
          </button>
        </div>
      </div>
      
      {/* Time of Day Category */}
      <div className="category-section">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Time of Day</h2>
          <button className="text-sm text-primary font-medium">Manage</button>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {timeOptions?.map((option: CategoryOption) => (
            <TimeCard 
              key={option.id} 
              option={option} 
              isActive={selectedOptions?.some(selected => selected.optionId === option.id) || false}
            />
          ))}
        </div>
      </div>
      
      {/* Energy Level Category */}
      <div className="category-section">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Energy Level</h2>
          <button className="text-sm text-primary font-medium">Manage</button>
        </div>
        
        <div className="bg-white rounded-lg p-5 shadow-sm border border-neutral-100">
          <RangeWithMarkers 
            value={energyLevel}
            onChange={setEnergyLevel}
            min={1}
            max={10}
            step={1}
            label="Energy Level"
          />
          <div className="mt-8 text-center">
            <div className="inline-block">
              <span className="text-sm font-medium">Current Energy Level:</span>
              <ScoreBadge score={energyLevel} className="ml-2 text-sm" />
            </div>
          </div>
        </div>
      </div>

      {/* Add Category Button */}
      <button 
        className="flex items-center justify-center w-full p-4 border border-dashed border-neutral-300 rounded-lg text-neutral-500 hover:text-primary hover:border-primary transition-colors"
        onClick={() => setAddCategoryOpen(true)}
      >
        <Plus className="h-5 w-5 mr-1" />
        <span>Add New Category</span>
      </button>
    </div>
  );
}
