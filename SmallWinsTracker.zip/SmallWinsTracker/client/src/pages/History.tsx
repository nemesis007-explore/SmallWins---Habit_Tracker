import { useState } from "react";
import { format, parseISO, startOfWeek, addDays } from "date-fns";
import { Calendar, Download, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { ScoreBadge } from "@/components/ui/score-badge";
import { DailyRecord, SummaryItem } from "@shared/schema";

export default function History() {
  // Fetch history data
  const { data: weeklyData, isLoading: weeklyLoading } = useQuery({
    queryKey: ['/api/daily-records/weekly'],
  });

  const { data: historyRecords, isLoading: historyLoading } = useQuery({
    queryKey: ['/api/daily-records'],
  });

  // Check if any data is still loading
  const isLoading = weeklyLoading || historyLoading;

  if (isLoading) {
    return <div className="flex justify-center py-8">Loading...</div>;
  }

  // Calculate weekly summary statistics
  const weeklyTotal = weeklyData?.reduce((sum: number, day: DailyRecord) => sum + day.totalScore, 0) || 0;
  const weeklyAverage = weeklyData?.length ? (weeklyTotal / weeklyData.length).toFixed(1) : 0;

  // Get the current week days
  const today = new Date();
  const startOfCurrentWeek = startOfWeek(today, { weekStartsOn: 1 }); // Start on Monday
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const day = addDays(startOfCurrentWeek, i);
    const dayData = weeklyData?.find((d: DailyRecord) => 
      format(parseISO(d.date.toString()), 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd')
    );
    return {
      date: day,
      score: dayData?.totalScore || 0,
      isToday: format(day, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd'),
      day: format(day, 'EEE')
    };
  });

  // Function to determine relative height for chart bar
  const getBarHeight = (score: number) => {
    const maxScore = Math.max(...weekDays.map(d => d.score), 10);
    return score ? `${(score / maxScore) * 100}%` : '5%'; // Minimum height for visibility
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">History</h2>
        <div className="flex items-center space-x-2">
          <Button variant="outline" className="bg-white border rounded-lg px-3 py-1.5 text-sm flex items-center">
            <Calendar className="h-4 w-4 mr-1" />
            Filter
          </Button>
          <Button variant="outline" className="bg-white border rounded-lg px-3 py-1.5 text-sm flex items-center">
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow overflow-hidden">
        {/* Weekly Summary */}
        <div className="bg-primary/5 p-5">
          <h3 className="font-semibold mb-3">Weekly Summary</h3>
          <div className="flex space-x-1">
            {weekDays.map((day, index) => (
              <div key={index} className="flex-1">
                <div className={`bg-white rounded-md p-2 text-center ${day.isToday ? 'ring-2 ring-primary' : ''}`}>
                  <div className={`text-xs ${day.isToday ? 'text-primary font-medium' : 'text-neutral-500'}`}>
                    {day.day}
                  </div>
                  <div className="h-20 flex flex-col justify-end mt-1">
                    <div 
                      className="bg-primary rounded-t w-full" 
                      style={{ height: getBarHeight(day.score) }}
                    ></div>
                  </div>
                  <div className="text-xs font-medium mt-1">{day.score || 0}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-4 text-sm">
            <span>Total: <strong className="text-primary">{weeklyTotal}</strong> points</span>
            <span>Average: <strong>{weeklyAverage}</strong> points/day</span>
          </div>
        </div>
        
        {/* Day Records */}
        <div className="p-5">
          <h3 className="font-semibold mb-3">Daily Records</h3>
          
          {historyRecords?.length > 0 ? (
            historyRecords.map((record: DailyRecord) => {
              // Parse the summary JSON
              const summary: SummaryItem[] = typeof record.summary === 'string' 
                ? JSON.parse(record.summary as string) 
                : record.summary;
              
              // Format the date
              const recordDate = new Date(record.date);
              const isToday = format(recordDate, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
              const isYesterday = format(recordDate, 'yyyy-MM-dd') === format(addDays(new Date(), -1), 'yyyy-MM-dd');
              
              return (
                <div key={record.id} className="border-b pb-4 mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <div>
                      <h4 className="font-medium">{format(recordDate, 'EEEE, MMMM d, yyyy')}</h4>
                      {isToday && <p className="text-sm text-neutral-500">Today</p>}
                      {isYesterday && <p className="text-sm text-neutral-500">Yesterday</p>}
                    </div>
                    <div className="text-lg font-semibold text-primary">{record.totalScore} points</div>
                  </div>
                  <div className="text-sm text-neutral-600">
                    <p>
                      {record.completedTasksCount} tasks completed
                      {summary.find(s => s.type === 'time') && ` • ${summary.find(s => s.type === 'time')?.name} active time`}
                      {summary.find(s => s.type === 'energy') && ` • Energy level: ${summary.find(s => s.type === 'energy')?.score}`}
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {summary.slice(0, 4).map((item, index) => (
                      <span key={index} className="text-xs bg-neutral-100 rounded-full px-2 py-0.5">
                        {item.name} +{item.score}
                      </span>
                    ))}
                    {summary.length > 4 && (
                      <span className="text-xs bg-neutral-100 rounded-full px-2 py-0.5">
                        +{summary.length - 4} more
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-8 text-neutral-500">
              No records found. Start completing tasks to see your history!
            </div>
          )}
          
          {historyRecords?.length > 0 && (
            <button className="w-full py-2 text-sm text-primary font-medium hover:bg-primary/5 rounded-lg">
              Load More
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
