import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import AppLayout from "@/components/AppLayout";
import Today from "@/pages/Today";
import Tasks from "@/pages/Tasks";
import History from "@/pages/History";
import { SmallWinsProvider } from "@/hooks/use-smallwins";

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Today} />
        <Route path="/tasks" component={Tasks} />
        <Route path="/history" component={History} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SmallWinsProvider>
          <Toaster />
          <Router />
        </SmallWinsProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
